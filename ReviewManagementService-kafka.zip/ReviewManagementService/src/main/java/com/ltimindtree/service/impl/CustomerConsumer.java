package com.ltimindtree.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.CustomerEvent;

@Service
public class CustomerConsumer {
	
	
private static final Logger logger=LoggerFactory.getLogger(CustomerConsumer.class);
	
	@KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${sping.kafka.consumer.group-id}")
	public void consume(CustomerEvent event) {
		logger.info(String.format("Customer event received in review Management service => %s", event.toString()));
		
	}

}
