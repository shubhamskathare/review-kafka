package com.ltimindtree.service.impl;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.ltimindtree.entity.Review;
import com.ltimindtree.exception.ReviewNotFoundException;
import com.ltimindtree.repository.ReviewRepository;
import com.ltimindtree.service.ReviewService;

@Service
public class ReviewServiceImpl implements ReviewService{
	
	@Autowired
	private ReviewRepository reviewRepo;

	@Override
	public Review createReview(Review review) {
		// TODO Auto-generated method stub
		return reviewRepo.save(review);
	}

	@Override
	public Review getReviewById(int id) throws ReviewNotFoundException {
		// TODO Auto-generated method stub
		return reviewRepo.findById(id).orElseThrow(()->new ReviewNotFoundException("Review", "Id", id));
	}

	@Override
	public Review updateReview(Review review, int id) throws ReviewNotFoundException {
		Review existingReview=  reviewRepo.findById(id).orElseThrow(()->new ReviewNotFoundException("Review", "Id", id));
		existingReview.setReviews(review.getReviews());
		existingReview.setRatings(review.getRatings());
		reviewRepo.save(existingReview);
		return existingReview;
	}
	
	

}
